#ifndef __LAB01_H__
#define	__LAB01_H__

void initialize_timer();

void timer_loop();

#endif	/* __LAB01_H__ */
